package com.mysite.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class newaccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.facebook.com/");
		
		
		
		
		driver.findElement(By.id("email")).sendKeys("email");
		


				
				driver.findElement(By.id("pass")).sendKeys("pass");
				

				driver.findElement(By.id("loginbutton")).click();
                  driver.close();
	}

}
